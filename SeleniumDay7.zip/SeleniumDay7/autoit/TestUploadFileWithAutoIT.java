package com.htc.autoit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.htc.selenium.drivers.WebDriversFactory;

public class TestUploadFileWithAutoIT {
	
		public static void main(String[] args) {
			
			TestUploadFileWithAutoIT example = new TestUploadFileWithAutoIT();
			example.uploadFileUseAutoITChrome();
		}

		/* Upload in Chrome. */
		public void uploadFileUseAutoITChrome()
		{
			WebDriver driver = null;
			try
			{	driver = WebDriversFactory.getWebdriver();
				
				 /* Upload page*/
				 String uploadFileDisplayUrl = "http://www.dev2qa.com/demo/upload/uploadFileTest.html";
								
				 // Display upload page.
				 driver.get(uploadFileDisplayUrl);
					
				 //Get the upload web element by it's name "uploadFileInputBox"
				 WebElement element = driver.findElement(By.name("uploadFileInputBox"));
					
				 //Click the upload button to open select file window.
				 element.click();
					
				 Thread.sleep(1000);

				 Runtime.getRuntime().exec("D:\\SeleniumDay7\\SeleniumDay7\\uploadFile.exe");
				System.out.println("Executed exe  file.........");
				 Thread.sleep(5000);
				 
				 // Click the upload form submit button. 
				 new WebDriverWait(driver,10).until(ExpectedConditions.presenceOfElementLocated(By.name("uploadFileSubmitBtn")));
				 driver.findElement(By.name("uploadFileSubmitBtn")).click();
				 
				 
				 Thread.sleep(3000);
					
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}finally
			{
				if(driver!=null)
				{
					//driver.close();
					driver = null;
				}
			}
		}
	}

