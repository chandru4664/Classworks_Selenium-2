package draganddrop;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.interactions.Action;

import org.openqa.selenium.interactions.Actions;

import com.htc.selenium.drivers.WebDriversFactory;

//import com.htc.selenium.drivers.WebDriversFactory;

public class DragAndDrop {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = WebDriversFactory.getWebdriver();
		//System.setProperty("webdriver.chrome.driver","e:\\SELENIUMDRIVERS\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
        
		String URL = "http://www.dhtmlx.com/docs/products/dhtmlxTree/index.shtml";

		driver.get(URL);

		// It is always advisable to Maximize the window before performing DragNDrop
		// action

		//driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);

		WebElement From = driver.findElement(By.xpath(
				"//*[@id=\"treebox1\"]/div/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[6]/td[2]/table/tbody/tr/td[4]/span"));
		
		WebElement To = driver.findElement(By.xpath(
				"//*[@id=\"treebox2\"]/div/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[1]/td[4]/span"));
		//Thread.sleep(3000);
		Actions builder = new Actions(driver);

		Action dragAndDrop = builder.clickAndHold(From).moveToElement(To).release(To).build();

		dragAndDrop.perform();
		Thread.sleep(3000);
	}

}