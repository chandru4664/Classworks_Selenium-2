package com.htc.basicapptest;

import java.util.ArrayList;

public class department  {
	
	public department() {
		super();
		// TODO Auto-generated constructor stub
	}
	ArrayList<employee> l = new ArrayList<employee>();
	
	
	public boolean add() {
		
	l.add(new employee(1,"Raj",25000.00));
	l.add(new employee(2,"Sam",35000.00));
	l.add(new employee(3,"Tom",45000.00));
	l.add(new employee(4,"Satya",25000.00));
	l.add(new employee(5,"Kiran",65000.00));
	return true;}
	
	public double getsalary(int empid) throws employeenotfoundexception{
		double salary=0.0;
		boolean found =false;
		for(employee o : l){
			if(o.getEmpid()==empid)
				 {found=true;
		         salary= o.getSalary();}
		}
		if (found==false)
		  throw new employeenotfoundexception() ;
		
		return 	salary;
		
	}
	
     
}
