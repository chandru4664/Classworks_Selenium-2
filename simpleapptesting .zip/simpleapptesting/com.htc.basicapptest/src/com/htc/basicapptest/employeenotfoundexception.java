package com.htc.basicapptest;

public class employeenotfoundexception extends Exception {
	String message;
	public employeenotfoundexception()
	{
		message="No emloyee found for the specified id";
	}
	
    public String toString(){
    	return message;}
}
