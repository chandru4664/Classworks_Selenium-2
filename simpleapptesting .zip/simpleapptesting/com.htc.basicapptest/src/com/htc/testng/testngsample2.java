package com.htc.testng;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.htc.basicapptest.department;
import com.htc.basicapptest.employeenotfoundexception;

public class testngsample2 {
	department o;
	@DataProvider(name="validEmpno")
 	public Object[][] setValidEmpno(){
 		Object[][] validEmpnos = {{1,5000.00},
 	                               {2,35000.00},
 									 {3,45000.00},
 									 {4,25000.00}};
 		return validEmpnos;
 	}
	@BeforeClass
	public void initialize(){
	 o= new department();
	 o.add();
	}

    
	
     
     
     @Test(dataProvider="validEmpno")
 	public void testMonthlySalary(int empno, double expectedSalary) throws employeenotfoundexception{
 		
 		double salary = o.getsalary(empno);
 		assertEquals(salary, expectedSalary);

 	}
}
