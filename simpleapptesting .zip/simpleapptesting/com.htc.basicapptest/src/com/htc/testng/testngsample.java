package com.htc.testng;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;
import com.htc.basicapptest.department;
import com.htc.basicapptest.employeenotfoundexception;

public class testngsample {
	department o;
	
	@BeforeClass
	public void initialize(){
	 o= new department();
	 o.add();
	}

    
	@Parameters("id")
	@Test
    public void testgetsalary(int id) throws employeenotfoundexception{
    	
		double actualvalue,expectedvalue;
    	actualvalue=o.getsalary(id);
    	expectedvalue=25000.00;
        assertEquals(actualvalue,expectedvalue);
          	    	
    }
	@Parameters("id")
	@Test(expectedExceptions = {employeenotfoundexception.class})
	public void testMonthlySalary(int id) throws employeenotfoundexception {
		
		double salary = o.getsalary(id);
		//assertEquals(salary, 45000.00);
	}}
