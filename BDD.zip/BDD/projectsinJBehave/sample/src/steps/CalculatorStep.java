package steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.steps.Steps;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import core.Calculator;


public class CalculatorStep extends Steps {

    private Calculator myCal;
    
    @Given("a calculator")
    public void setCal() {
            myCal=new Calculator();
            System.out.println("Created");
    }
    
    
    @When(" add $number1 and $number2")
    public void AddCal(@Named("number1")int x,@Named("number2")int y) {
            myCal.addTwoNumber(x, y);
    }

    @Then("the outcome should be $result")
    public void testResult(@Named("result")int output) {
             Assert.assertEquals(output, myCal.getresult());
    }
    
}
