package steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.annotations.Aliases;
import org.junit.Assert;
import core.Item;
import core.Store;
import org.jbehave.core.steps.Steps;

public class Mysteps extends Steps {
	 private Item o;
	 private Store obj;
	 
	 @Given("A store")
	 public void createstore() {
		 obj=new Store();
	 }
	 
     @Given("An item with $name and $price")
	 public void newitem(@Named("name")String item,@Named("price")double price){
		o=new Item(item,price);
	}
     @When("Item price does not exceed $pricelimit") 
     @Aliases(values={"Item price is less than $pricelimit",
     "Item price is bound to to $pricelimit"}) 
     public void checkmaxpricelimit(@Named("pricelimit")double limit) {
    	 boolean checkmax=false;
    	 o.setmaxprice(limit);
    	 checkmax=o.checkprice();
    	 Assert.assertTrue(checkmax);
     }
     
     @Then("Item should be added to the Store")
     public void addtostore() {
    	boolean addstatus=false;
    	addstatus= obj.additem(o);
    	Assert.assertTrue(addstatus);
     }
     
}