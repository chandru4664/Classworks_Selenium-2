package steps;
import org.jbehave.core.annotations.*;

import org.junit.Assert;
import org.jbehave.core.steps.Steps;
public class MySteps extends Steps{
	
	@Given("a step that is executed before each scenario")
	public void givenAStepThatIsExecutedBeforeEachScenario(){
		 Assert.assertTrue(true); 
	}
	
	@Given("a step that is executed after each scenario regardless of outcome")
	
	public void givenAStepThatIsExecutedAfterEachScenarioRegardlessOfOutcome(){
	System.out.println("This is executed after each scenario");
	}

	
	  
	@Given("a step that is executed after each successful scenario")
	public void givenAStepThatIsExecutedAfterEachSuccessfulScenario(){
		System.out.println("This is executed after each successful scenario");
	} 
	
	
	@AfterScenario
	public void givenAStepThatIsExecutedAfterEachFailureScenario(){
		System.out.println("This is executed after each failed scenario");	
	} 
	
	@Given("step represents a precondition to an event")
	public void givenStepRepresentsAPreconditionToAnEvent(){
		System.out.println("This is the given precondition");
	}
	
	@When("step represents the occurrence of the event")

	public void whenStepRepresentsTheOccurrenceOfTheEvent(){
		System.out.println("Event occured");
	}
	
	@Then("step represents the outcome of the event")
	public void thenStepRepresentsTheOutcomeOfTheEvent(){
		System.out.println("This is the outcome");
	}
	
	@Given("a <precondition>")//instead of $ use <> to take multiple parameters
	public void givenAprecondition(@Named("precondition")String x){
		 System.out.println("precondition is"+x);
	}
	
	@When("a negative event occurs")
	public void whenANegativeEventOccurs(){
		 System.out.println("Negative event has occured.");	 
	}
	@Then("the outcome should <be-captured>")
	public void thenATheOutcomeShouldbecaptured(@Named("be-captured")String y){
		 System.out.println("For the given precondition ,the outcome should"+y);	
	}
	
}